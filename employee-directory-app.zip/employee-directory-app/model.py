employee_directory = {
    "joel": {
        "name": "Joel Burton",
        "email": "joel@hackbrightacademy.com",
        "favorite_food": "peanut-butter pretzels",
        "position": "Vice President of Education"
    },

    "henry": {
        "name": "Henry Chen",
        "email": "henry@hackbrightacademy.com",
        "favorite_food": "Chinese donuts",
        "position": "Instructor"
    },

    "meggie": {
        "name": "Meggie Mahnken",
        "email": "meggie@hackbrightacademy.com",
        "favorite_food": "Foods with single, overpowering flavors",
        "position": "Instructor"
    },

    "bonnie": {
        "name": "Bonnie Schulkin",
        "email": "bonnie@hackbrightacademy.com",
        "favorite_food": "chocolate cake with raspberries",
        "position": "Instructor"
    },

    "kara": {
        "name": "Kara DeWalt",
        "email": "kara@hackbrightacademy.com",
        "favorite_food": "gummy bears",
        "position": "Lab Instructor"
    },

    "meg": {
        "name": "Meg Bishop",
        "email": "meg@hackbrightacademy.com",
        "favorite_food": "waffles",
        "position": "Lab Instructor"
    },

    "katie": {
        "name": "Katie Byers",
        "email": "katiebyers@hackbrightacademy.com",
        "favorite_food": "sushi",
        "position": "Lab Instructor"
    },

    "leslie": {
        "name": "Leslie Castellanos",
        "email": "leslie@hackbrightacademy.com",
        "favorite_food": "dark chocolate",
        "position": "Teaching Assistant"
    },

    "allyson": {
        "name": "Allyson McKnight",
        "email": "ally@hackbrightacademy.com",
        "favorite_food": "jamon iberico",
        "position": "Lab Instructor"
    },

    "jenn": {
        "name": "Jennifer Griffith-Delgado",
        "email": "jennifer@hackbrightacademy.com",
        "favorite_food": "warm chocolate chip cookies a la mode",
        "position": "Teaching Assistant"
    },

    "agnes": {
        "name": "Agnes Klimaite",
        "email": "agnes@hackbrightacademy.com",
        "favorite_food": "havarti cheese",
        "position": "Teaching Assistant"
    },

    "balloonicorn": {
        "name": "Balloonicorn",
        "email": "balloonicorn@hackbrightacademy.com",
        "favorite_food": "magical rainbow cupcakes with iridescent sprinkles",
        "position": "Support Staff"
    },

    "mel": {
        "name": "Mel",
        "email": "mel@ubermelon.com",
        "favorite_food": "Powerbars",
        "position": "The Boss"
    }
}
